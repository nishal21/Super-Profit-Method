<?php
session_start();
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    // Simulating Payment Success
    $user_id = $_SESSION['user_id'];

    // Add logic to verify UPI Payment if required
    echo "Payment successful! <a href='https://t.me/your_telegram_group_link'>Join Telegram Group</a>";
}
?>
